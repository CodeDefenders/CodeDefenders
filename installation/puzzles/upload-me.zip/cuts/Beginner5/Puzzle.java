public class Puzzle {
  public int run(int x, int y) {

    if (x == 5 && y == 7) {
      return x + y;
    }
    return x;
  }
}
