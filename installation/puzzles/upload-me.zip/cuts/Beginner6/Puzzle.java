public class Puzzle {

    public int testMe(int x, int y) {
        int z = 4;
        if (x == 42) {
            z = 5;
        }
        if (y == 100) {
            z++;
        }
        return z;
    }

}
