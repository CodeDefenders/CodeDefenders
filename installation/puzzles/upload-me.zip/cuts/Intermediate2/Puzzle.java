public class Puzzle {
  public int run(int x, int y) {

    if (x == 5) {
      return 0;
    } else if(y == 7) {
      return 1;
    } else {
      return 1;
    }
  }
}
