public class Puzzle {
    public int foo(int x) {
        return x + 1;
    }

    public int bar(int x) {
        return x + 1;
    }
}
