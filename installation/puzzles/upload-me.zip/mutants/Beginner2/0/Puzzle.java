public class Puzzle {
    public int run(int x) {
        if (x == 5) {
            return 5;
        }
        return (x * 8);
    }
}
