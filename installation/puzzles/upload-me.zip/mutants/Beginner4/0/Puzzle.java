public class Puzzle {

    public int run(int x) {
        int y = 1;
        if (x == 5) {
            y = 5;
        }
        return (y * 8);
    }

}
