public class Puzzle {
  public int run(int x) {
    int y = 0;
    if (x == 5) {
      y = 3;
    }
    return (y * 8);
  }
}
