public class Puzzle {
  
  public int testMe(int x, int y) {
    int z = 4;
    if(x == 42) {
      z = 6;
    }
    if(y == 100) {
      z++;
    }
    return z;
  }
}
