public class Puzzle {

    public int testMe(int x, int y) {
        int z = 3;

        if (x == 42) {
            z = 1;
        }

        if (y == 100) {
            z = 2;
        }

        return z;
    }

}
