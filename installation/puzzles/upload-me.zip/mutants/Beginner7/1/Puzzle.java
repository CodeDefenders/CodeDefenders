public class Puzzle {

    public int testMe(int x, int y) {

        int z = 0;

        if(x == 42) {
            z = 4;
        }

        if(y == 100) {
            z = 2;
        }

        return z;
    }
}
