public class Puzzle {

    public int run(int x, int y) {
        if (x == 5) {
            if (y == 7) {
                return 0;
            }
        }
        return 3;
    }

}
