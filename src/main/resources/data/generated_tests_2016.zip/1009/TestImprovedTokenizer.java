import org.junit.*;
import static org.junit.Assert.*;

// Game: 1009
public class TestImprovedTokenizer {

	@Test(timeout = 4000)
	public void test_1_1454() throws Throwable {
		String token1     = "a";
		String token2     = "bb";
		String token3     = "ccc";
		String delimiter1 = ",";

		String input      = token1 + delimiter1 + token2 + delimiter1 + token3;
		String delimiters = delimiter1;
    
		ImprovedTokenizer tokenizer = new ImprovedTokenizer(input, delimiters);
		boolean matched1 = tokenizer.hasNext() && tokenizer.next().equals(token1);
		boolean matched2 = tokenizer.hasNext() && tokenizer.next().equals(token2);
		boolean matched3 = tokenizer.hasNext() && tokenizer.next().equals(token3);
		boolean finished = !tokenizer.hasNext();

		assertTrue(matched1 && matched2 && matched3 && finished);
		assertEquals(tokenizer.previousDelimiter(), delimiter1);
	}

	@Test(timeout = 4000)
	public void test_2_1459() throws Throwable {
		String token1     = "a";
		String token2     = "b";
		String delimiter1 = ",";

		String input      = token1 + delimiter1 + token2;
		String delimiters = delimiter1;

		ImprovedTokenizer tokenizer = new ImprovedTokenizer(input, delimiters);

		// verify state machine values
		boolean stateStartVerified = ImprovedTokenizer.STATE_START == 0;
		boolean stateStopVerified = ImprovedTokenizer.STATE_STOP == 1;
		boolean stateBeforeTokenVerified = ImprovedTokenizer.STATE_BEFORE_TOKEN == 2;
		boolean stateMatchingTokenVerified = ImprovedTokenizer.STATE_MATCHING_TOKEN == 3;
		boolean stateAfterTokenVerified = ImprovedTokenizer.STATE_AFTER_TOKEN == 4;
		boolean stateMatchStopVerified = ImprovedTokenizer.STATE_MATCH_STOP == 5;
		assertTrue(stateStartVerified && stateStopVerified && stateBeforeTokenVerified && stateMatchingTokenVerified && stateAfterTokenVerified && stateMatchStopVerified);

		// verify state machine behavior
		assertTrue(tokenizer.keepParsing(ImprovedTokenizer.STATE_START) &&
			!tokenizer.keepParsing(ImprovedTokenizer.STATE_STOP) &&
			tokenizer.keepParsing(ImprovedTokenizer.STATE_BEFORE_TOKEN) &&
			tokenizer.keepParsing(ImprovedTokenizer.STATE_MATCHING_TOKEN) &&
			!tokenizer.keepParsing(ImprovedTokenizer.STATE_AFTER_TOKEN) &&
			!tokenizer.keepParsing(ImprovedTokenizer.STATE_MATCH_STOP));
	}

	@Test(timeout = 4000)
	public void test_3_1462() throws Throwable {
		assertEquals(128, ImprovedTokenizer.BUF_SIZE);
		assertEquals(1, ImprovedTokenizer.STATE_STOP);
	}

	@Test(timeout = 4000)
	public void test_4_1465() throws Throwable {
		String token1     = "aa";
		String token2     = "bb";
		String delimiter1 = ",";

		String input      = token1 + delimiter1 + token2;
		String delimiters = delimiter1;

		ImprovedTokenizer tokenizer = new ImprovedTokenizer(input, delimiters);

		boolean verifiedStartState =
			tokenizer.myState == ImprovedTokenizer.STATE_START &&
			tokenizer.myBuffer == null &&
			tokenizer.myToken == null &&
			tokenizer.myPreviousDelimiter == null;

		boolean advanced1 = tokenizer.advance();

		boolean verifiedAfterTokenState =
			tokenizer.myState == ImprovedTokenizer.STATE_AFTER_TOKEN &&
			tokenizer.myBuffer.toString().equals(delimiter1) &&
			tokenizer.myToken.equals(token1) &&
			tokenizer.myPreviousDelimiter == null;

		boolean advanced2 = tokenizer.advance();

		boolean verifiedMatchStopState =
			tokenizer.myState == ImprovedTokenizer.STATE_MATCH_STOP &&
			tokenizer.myToken.equals(token2) &&
			tokenizer.myPreviousDelimiter.equals(delimiter1);

		assertTrue(verifiedStartState && verifiedAfterTokenState && verifiedMatchStopState);
		assertTrue(advanced1 && advanced2);
	}

	@Test(timeout = 4000)
	public void test_5_1468() throws Throwable {
		String token1     = "aa";
		String token2     = "bb";
		String delimiter1 = ",";

		String input      = token1 + delimiter1 + token2;
		String delimiters = delimiter1;

		java.io.StringReader reader = new java.io.StringReader(input);
		ImprovedTokenizer tokenizer = new ImprovedTokenizer(reader, delimiters);

		assertTrue(tokenizer.myInput == reader &&
			tokenizer.myDelimiters.equals(delimiters) &&
			tokenizer.myState == ImprovedTokenizer.STATE_START &&
			tokenizer.myBuffer == null &&
			tokenizer.myToken == null &&
			tokenizer.myPreviousDelimiter == null);
	}

	@Test(timeout = 4000)
	public void test_6_1471() throws Throwable {
		String token1     = "aa";
		String token2     = "bb";
		String delimiter1 = ",";

		String input      = token1 + delimiter1 + token2;
		String delimiters = delimiter1;

		// create tokenizer and initialize with custom stream
		ImprovedTokenizer tokenizer = new ImprovedTokenizer("", "");
		java.io.InputStream stream = new java.io.ByteArrayInputStream(input.getBytes());
		tokenizer.initialize(stream, delimiters);

		// extract stored string
		char[] temp = new char[100];
		int length = tokenizer.myInput.read(temp);
		String storedInput = new String(temp, 0, length);

		// verify state
		assertTrue(storedInput.equals(input) &&
			tokenizer.myDelimiters.equals(delimiters) &&
			tokenizer.myState == ImprovedTokenizer.STATE_START &&
			tokenizer.myBuffer == null &&
			tokenizer.myToken == null &&
			tokenizer.myPreviousDelimiter == null);
	}

	@Test(timeout = 4000)
	public void test_7_1472() throws Throwable {
		String token1     = "aa";
		String token2     = "bb";
		String delimiter1 = ",";
		int illegalState  = 1337;

		String input      = token1 + delimiter1 + token2;
		String delimiters = delimiter1;

		ImprovedTokenizer tokenizer = new ImprovedTokenizer(input, delimiters);

		tokenizer.myState = illegalState;
		try
		{
			tokenizer.stop();
			// stop() must have triggered an exception
			assertTrue(false);
		}
		catch (Exception e)
		{
			assertEquals(e.getMessage(), "Invalid state, " + illegalState);
		}
	}

	@Test(timeout = 4000)
	public void test_8_1473() throws Throwable {
		String token1     = "aa";
		String token2     = "bb";
		String delimiter1 = ",";
		int illegalState  = 1337;

		String input      = token1 + delimiter1 + token2;
		String delimiters = delimiter1;

		ImprovedTokenizer tokenizer = new ImprovedTokenizer(input, delimiters);

		tokenizer.myState = illegalState;
		try
		{
			tokenizer.next();
			// next() must have triggered an exception
			assertTrue(false);
		}
		catch (Exception e)
		{
			assertEquals(e.getMessage(), "invalid state: " + illegalState);
		}
	}

	@Test(timeout = 4000)
	public void test_9_1474() throws Throwable {
		java.io.Reader r = new java.io.StringReader("Some,text,here");
		ImprovedTokenizer im = new ImprovedTokenizer(r, ",");
	    assertEquals(true, im.advance());
	}

	@Test(timeout = 4000)
	public void test_10_1475() throws Throwable {
		String token1     = "aa";
		String token2     = "bb";
		String delimiter1 = ",";
		int illegalState  = 1337;

		String input      = token1 + delimiter1 + token2;
		String delimiters = delimiter1;

		ImprovedTokenizer tokenizer = new ImprovedTokenizer(input, delimiters);

		tokenizer.myState = illegalState;
		try
		{
			tokenizer.advance();
			// advance() must have triggered an exception
			assertTrue(false);
		}
		catch (Exception e)
		{
			assertEquals(e.getMessage(), "Invalid state, " + illegalState);
		}
	}

	@Test(timeout = 4000)
	public void test_11_1476() throws Throwable {
		String delimiter1 = ",";
		int illegalState  = -1;

		// empty input
		String input      = "";
		String delimiters = delimiter1;

		ImprovedTokenizer tokenizer = new ImprovedTokenizer(input, delimiters);
    
		tokenizer.myState = illegalState;
		try
		{
			tokenizer.advance();
			// advance() must have triggered an exception
			assertTrue(false);
		}
		catch (RuntimeException e)
		{
			assertEquals(e.getMessage(), "Invalid state, " + illegalState);
		}
	}

	@Test(timeout = 4000)
	public void test_12_1479() throws Throwable {
		java.io.Reader r = new java.io.StringReader(",");
		ImprovedTokenizer im = new ImprovedTokenizer(r, ",");
		assertFalse(im.hasNext());
	}

	@Test(timeout = 4000)
	public void test_13_1483() throws Throwable {
		String token1     = "aa";
		String token2     = "bb";
		String delimiter1 = ",";

		String input      = token1 + delimiter1 + token2;
		String delimiters = delimiter1;

		java.io.StringReader reader = new java.io.StringReader(input);

		// identical to Test 1468, but this time I call initialize() manually
		// let's see if this makes any difference :)
		ImprovedTokenizer tokenizer = new ImprovedTokenizer("", "");
		tokenizer.initialize(reader, delimiters);
		assertTrue(tokenizer.myInput == reader &&
			tokenizer.myDelimiters.equals(delimiters) &&
			tokenizer.myState == ImprovedTokenizer.STATE_START &&
			tokenizer.myBuffer == null &&
			tokenizer.myToken == null &&
			tokenizer.myPreviousDelimiter == null);
	}

	@Test(timeout = 4000)
	public void test_14_1484() throws Throwable {
		String token1     = "a";
		String token2     = "b";
		String delimiter1 = ",";

		String input      = token1 + delimiter1 + token2;
		String delimiters = delimiter1;

		ImprovedTokenizer tokenizer = new ImprovedTokenizer(input, delimiters);

		tokenizer.myState = ImprovedTokenizer.STATE_START;
		boolean verifiedStateStart = tokenizer.hasNext() == true;

		tokenizer.myState = ImprovedTokenizer.STATE_BEFORE_TOKEN;
		boolean verifiedStateBeforeToken = tokenizer.hasNext() == true;

		tokenizer.myState = ImprovedTokenizer.STATE_AFTER_TOKEN;
		boolean verifiedStateAfterToken = tokenizer.hasNext() == true;

		tokenizer.myState = ImprovedTokenizer.STATE_MATCH_STOP;
		boolean verifiedStateMatchStop = tokenizer.hasNext() == true;

		tokenizer.myState = ImprovedTokenizer.STATE_STOP;
		boolean verifiedStateStop = tokenizer.hasNext() == false;

		tokenizer.myState = ImprovedTokenizer.STATE_MATCHING_TOKEN;
		boolean verifiedStateMatchingToken = tokenizer.hasNext() == false;

		assertTrue(verifiedStateStart &&
			verifiedStateBeforeToken &&
			verifiedStateAfterToken &&
			verifiedStateMatchStop &&
			verifiedStateStop &&
			verifiedStateMatchingToken);
	}

	@Test(timeout = 4000)
	public void test_15_1485() throws Throwable {
		// similar to test 1484, but without input

		ImprovedTokenizer tokenizer = new ImprovedTokenizer("", ",");

		tokenizer.myState = ImprovedTokenizer.STATE_START;
		boolean verifiedStateStart = tokenizer.hasNext() == false;

		tokenizer.myState = ImprovedTokenizer.STATE_BEFORE_TOKEN;
		boolean verifiedStateBeforeToken = tokenizer.hasNext() == false;

		tokenizer.myState = ImprovedTokenizer.STATE_AFTER_TOKEN;
		boolean verifiedStateAfterToken = tokenizer.hasNext() == true;

		tokenizer.myState = ImprovedTokenizer.STATE_MATCH_STOP;
		boolean verifiedStateMatchStop = tokenizer.hasNext() == true;

		tokenizer.myState = ImprovedTokenizer.STATE_STOP;
		boolean verifiedStateStop = tokenizer.hasNext() == false;

		tokenizer.myState = ImprovedTokenizer.STATE_MATCHING_TOKEN;
		boolean verifiedStateMatchingToken = tokenizer.hasNext() == false;

		assertTrue(verifiedStateStart &&
			verifiedStateBeforeToken &&
			verifiedStateAfterToken &&
			verifiedStateMatchStop &&
			verifiedStateStop &&
			verifiedStateMatchingToken);
	}

	@Test(timeout = 4000)
	public void test_16_1488() throws Throwable {
		String token1     = "aa";
		String token2     = "bb";
		String delimiter1 = ".";
		String delimiter2 = ",";

		// multi-character delimiter test
		String input      = token1 + delimiter1 + delimiter2 + token2;
		String delimiters = delimiter1 + delimiter2;

		ImprovedTokenizer tokenizer = new ImprovedTokenizer(input, delimiters);

		// parse first token and start with first delimiter character
		boolean delimiter1Verified = tokenizer.advance() &&
			tokenizer.myState == ImprovedTokenizer.STATE_AFTER_TOKEN &&
			tokenizer.myBuffer.toString().contentEquals(delimiter1);

		// add second delimiter character
		char c = (char) tokenizer.myInput.read();
		boolean delimiter2Verified = tokenizer.afterToken(c) == ImprovedTokenizer.STATE_BEFORE_TOKEN &&
			tokenizer.myBuffer.toString().contentEquals(delimiters);

		// start with next token
		c = (char) tokenizer.myInput.read();
		boolean previousDelimiterVerified = tokenizer.beforeToken(c) == ImprovedTokenizer.STATE_MATCHING_TOKEN &&
			tokenizer.myPreviousDelimiter.equals(delimiters) &&
			tokenizer.myBuffer.toString().contentEquals(token2.substring(0, 1));

		assertTrue(delimiter1Verified && delimiter2Verified && previousDelimiterVerified);
	}

	@Test(timeout = 4000)
	public void test_17_1492() throws Throwable {
		String token1     = "aa";
		String token2     = "bb";
		String delimiter1 = ".";
		String delimiter2 = ",";

		String input      = token1 + delimiter1 + token2;
		String delimiters = delimiter1 + delimiter2;

		// create tokenizer and set random values
		ImprovedTokenizer tokenizer = new ImprovedTokenizer("", "");
		tokenizer.myState = 42;
		tokenizer.myBuffer = new StringBuffer();
		tokenizer.myToken = new String();
		tokenizer.myPreviousDelimiter = new String();
		tokenizer.myInput = new java.io.StringReader(input);
		tokenizer.myDelimiters = new String();

		java.io.Reader reader = new java.io.StringReader(input);
    
		// call initialize method and verify that all values are reset
		tokenizer.initialize(reader, delimiters);
		assertTrue(tokenizer.myInput == reader &&
			tokenizer.myDelimiters.equals(delimiters) &&
			tokenizer.myState == ImprovedTokenizer.STATE_START &&
			tokenizer.myBuffer == null &&
			tokenizer.myToken == null &&
			tokenizer.myPreviousDelimiter == null);
	}

	@Test(timeout = 4000)
	public void test_18_1493() throws Throwable {
		java.io.Reader reader = new java.io.StringReader("aa");
		ImprovedTokenizer tokenizer = new ImprovedTokenizer("", "");

		// verify that empty delimiters are not changed in initialize method
		tokenizer.myDelimiters = new String("xxx");
		tokenizer.initialize(reader, "");
		assertEquals(tokenizer.myDelimiters, "");

		// verify that null delimiters are accepted (even though they will make tokenizer crash)
		tokenizer.myDelimiters = new String("yyy");
		tokenizer.initialize(reader, null);
		assertEquals(tokenizer.myDelimiters, null);
	}

	@Test(timeout = 4000)
	public void test_19_1498() throws Throwable {
		String token1     = "a";
		String token2     = "b";
		String delimiter1 = ",";

		String input      = token1 + delimiter1 + token2;
		String delimiters = delimiter1;

		ImprovedTokenizer tokenizer = new ImprovedTokenizer(input, delimiters);

		// extract stored string
		char[] temp = new char[100];
		int length = tokenizer.myInput.read(temp);
		String storedInput = new String(temp, 0, length);

		assertEquals(storedInput, input);
	}

	@Test(timeout = 4000)
	public void test_20_1508() throws Throwable {
		try{
			ImprovedTokenizer obj = new ImprovedTokenizer((String)null, ",");
		}catch(NullPointerException e){}
	}

	@Test(timeout = 4000)
	public void test_21_1509() throws Throwable {
		String token1     = "a";
		String token2     = "b";
		String delimiter1 = ",";

		String input      = token1 + delimiter1 + token2;
		String delimiters = delimiter1;

		ImprovedTokenizer tokenizer = new ImprovedTokenizer(input, delimiters);

		// tokenizer.myInput already verified by test 1498
		assertTrue(tokenizer.myDelimiters.equals(delimiters) &&
			tokenizer.myState == ImprovedTokenizer.STATE_START &&
			tokenizer.myBuffer == null &&
			tokenizer.myToken == null &&
			tokenizer.myPreviousDelimiter == null);
	}

	@Test(timeout = 4000)
	public void test_22_1512() throws Throwable {
		assertEquals(128, ImprovedTokenizer.BUF_SIZE);
	}

	@Test(timeout = 4000)
	public void test_23_1513() throws Throwable {
		ImprovedTokenizer im = new ImprovedTokenizer("some,text", ",");
		boolean correct = im.hasNext();
	    im.myState = 1;
	    assertNotEquals(correct, im.hasNext());
	}

	@Test(timeout = 4000)
	public void test_24_1514() throws Throwable {
		ImprovedTokenizer im = new ImprovedTokenizer("some,text", ",");
	    im.stop();
	    assertTrue(im.myToken==null);
	}

	@Test(timeout = 4000)
	public void test_25_1518() throws Throwable {
		String token = new String("x");
		String previousDelimiter = new String("y");
		StringBuffer buffer = new StringBuffer("z");

		ImprovedTokenizer tokenizer = new ImprovedTokenizer("a.b.c", ".");

		// verify behavior of stop() method and make sure internal variables are not damaged
		boolean valid = true;

		// STATE_START
		tokenizer.myState = ImprovedTokenizer.STATE_START;
		tokenizer.myToken = token;
		tokenizer.myPreviousDelimiter = previousDelimiter;
		tokenizer.myBuffer = buffer;

		valid &= tokenizer.stop() == ImprovedTokenizer.STATE_STOP;
		valid &= tokenizer.myToken == null;
		valid &= tokenizer.myPreviousDelimiter == null;
		valid &= tokenizer.myBuffer == null;

		// STATE_BEFORE_TOKEN
		tokenizer.myState = ImprovedTokenizer.STATE_BEFORE_TOKEN;
		tokenizer.myToken = token;
		tokenizer.myPreviousDelimiter = previousDelimiter;
		tokenizer.myBuffer = buffer;

		valid &= tokenizer.stop() == ImprovedTokenizer.STATE_STOP;
		valid &= tokenizer.myToken == null;
		valid &= tokenizer.myPreviousDelimiter == null;
		valid &= tokenizer.myBuffer == null;

		// STATE_STOP
		tokenizer.myState = ImprovedTokenizer.STATE_STOP;
		tokenizer.myToken = token;
		tokenizer.myPreviousDelimiter = previousDelimiter;
		tokenizer.myBuffer = buffer;

		valid &= tokenizer.stop() == ImprovedTokenizer.STATE_STOP;
		valid &= tokenizer.myToken == null;
		valid &= tokenizer.myPreviousDelimiter == null;
		valid &= tokenizer.myBuffer == null;

		// STATE_MATCHING_TOKEN
		tokenizer.myState = ImprovedTokenizer.STATE_MATCHING_TOKEN;
		tokenizer.myToken = token;
		tokenizer.myPreviousDelimiter = previousDelimiter;
		tokenizer.myBuffer = buffer;

		valid &= tokenizer.stop() == ImprovedTokenizer.STATE_MATCH_STOP;
		valid &= tokenizer.myToken.contentEquals(buffer);
		valid &= tokenizer.myPreviousDelimiter.equals(previousDelimiter);
		valid &= tokenizer.myBuffer == null;

		// STATE_AFTER_TOKEN
		tokenizer.myState = ImprovedTokenizer.STATE_AFTER_TOKEN;
		tokenizer.myToken = token;
		tokenizer.myPreviousDelimiter = previousDelimiter;
		tokenizer.myBuffer = buffer;

		valid &= tokenizer.stop() == ImprovedTokenizer.STATE_MATCH_STOP;
		valid &= tokenizer.myToken.equals(token);
		valid &= tokenizer.myPreviousDelimiter.equals(previousDelimiter);
		valid &= tokenizer.myBuffer == null;

		// STATE_MATCH_STOP
		tokenizer.myState = ImprovedTokenizer.STATE_MATCH_STOP;
		tokenizer.myToken = token;
		tokenizer.myPreviousDelimiter = previousDelimiter;
		tokenizer.myBuffer = buffer;
		try
		{
			tokenizer.stop();
			valid = false;
		}
		catch(Exception e)
		{
		}

		// finalize
		assertTrue(valid);
	}

	@Test(timeout = 4000)
	public void test_26_1519() throws Throwable {
		ImprovedTokenizer im = new ImprovedTokenizer("text,here", ",");
		im.next();
		int temp = im.stop();
		assertTrue(temp == im.STATE_MATCH_STOP);
		assertTrue(im.myBuffer == null);
	}

}
