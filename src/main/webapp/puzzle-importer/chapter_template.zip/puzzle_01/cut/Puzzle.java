public class Puzzle {

}
