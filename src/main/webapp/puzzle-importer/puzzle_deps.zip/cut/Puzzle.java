package org.example.puzzle;

import org.example.puzzle.deps.Hello;

public class Puzzle {
    { Hello.hello(); }

    public int foo(int x) {
        return x + 1;
    }

    public int bar(int x) {
        return x - 1;
    }

}
