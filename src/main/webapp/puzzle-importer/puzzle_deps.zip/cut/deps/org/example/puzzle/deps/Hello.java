package org.example.puzzle.deps;

public class Hello {
    public static void hello() {
        System.out.println("hello");
    }
}
